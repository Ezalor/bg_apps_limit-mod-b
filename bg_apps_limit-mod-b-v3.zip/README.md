# 修改 bg_apps_limit 限制（B Plan）
将后台应用限制修改为 42。自用于一加 3 氢 OS。

将 build.prop 修改为：

ro.sys.fw.bg_apps_limit=42

B Plan：替换整个 build.prop

当前版本：氢 OS 2.5.5。